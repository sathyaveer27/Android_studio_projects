package com.example.converter_self;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private RadioButton rb1;
    private RadioButton rb2;
    private EditText input;
    private TextView result;
    private TextView history;
    private TextView tv1;
    private TextView tv2;
    String h;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        input = findViewById(R.id.input);
        rb1 = findViewById(R.id.f_c);
        rb2 = findViewById(R.id.c_f);
        result = findViewById(R.id.result);
        tv1 = findViewById(R.id.tv1);
        tv2 = findViewById(R.id.tv2);
        history = findViewById(R.id.history);
        history.setMovementMethod(new ScrollingMovementMethod());
        setView();



    }
    public void setView(){
        rb1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Enter in Farenhite",Toast.LENGTH_SHORT).show();
                tv1.setText(R.string.farenhite_degrees);
                tv2.setText(R.string.celsius_degrees);
            }
        });
        rb2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Enter in Celsius", Toast.LENGTH_SHORT).show();
                tv1.setText(R.string.celsius_degrees);
                tv2.setText(R.string.farenhite_degrees);
            }
        });
    }
    public void convert (View v) {
        String f = input.getText().toString().trim();

        if (rb1.isChecked()) {
            if(f.isEmpty())
                Toast.makeText(getApplicationContext(),"Enter Farenhite Value!!!!", Toast.LENGTH_SHORT).show();
            else {
                //String f = input.getText().toString().trim();
                Float f1 = Float.parseFloat(f);
                String ans;
                double c = (f1 - 32) / 1.8;
                ans = String.format("%.1f", c);
                if (!ans.trim().isEmpty())
                    result.setText(ans);
                if (h != null)
                    h = f + " F" + ">>>" + ans + " C\n" + h;
                else
                    h = f + " F" + ">>>" + ans + " C\n";
                history.setText(h);
            }

        } else if (rb2.isChecked()) {

            if (f.isEmpty())
                Toast.makeText(getApplicationContext(), "Enter Celsius Value!!!!", Toast.LENGTH_SHORT).show();
            else{
                //String f = input.getText().toString().trim();
                Log.d(TAG, "convert: " + f);
                Double f1 = Double.parseDouble(f);
                String ans;
                double c = (f1 * 9 / 5) + 32;
                Log.d(TAG, "convert: " + c);
                ans = String.format("%.1f", c);
                if (!ans.trim().isEmpty())
                    result.setText(ans);
                if (h != null)
                    h = f + " C" + ">>>" + ans + " F\n" + h;
                else
                    h = f + " C" + ">>>" + ans + " F\n";
                history.setText(h);
            }
        }


    }
    public void clear(View v){
        h = "";
        history.setText(h);

    }

    protected void onSaveInstanceState(Bundle outState)
    {
        super.onSaveInstanceState(outState);
        outState.putString("1",history.getText().toString());
        outState.putString("2",result.getText().toString());
        outState.putString("3",h);
    }

    protected void onRestoreInstanceState(Bundle savedInstanceState)
    {
        super.onRestoreInstanceState(savedInstanceState);
        history.setText(savedInstanceState.getString("1"));
        result.setText(savedInstanceState.getString("2"));
        h= savedInstanceState.getString("3");
    }

}
