package com.example.stock;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.Context;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, View.OnLongClickListener {

    private RecyclerView recycle;
    HashMap<String, String> map;
    private ArrayList<Stocks> myStocks= new ArrayList<>();
    private StockAdapter sAdapter;
    private SwipeRefreshLayout srl;
    SQL_liteDb sql_liteDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recycle = findViewById(R.id.stock_recycler);
        sAdapter = new StockAdapter(myStocks , this);
        recycle.setAdapter(sAdapter);
        recycle.setLayoutManager(new LinearLayoutManager(this));
        srl = findViewById(R.id.refresh);
        srl.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                if(!Network_check()){
                    srl.setRefreshing(false);
                    errorAlert2();
                }
                else {
                    refresh_stocks();}

            }
        });

        sql_liteDb = new SQL_liteDb(this);

        if (Network_check()) {
            new LoadAll_Stocks(MainActivity.this).execute();
            ArrayList<Stocks> stocks_list = sql_liteDb.loadStocks();
            if (!Network_check()) {
                myStocks.addAll(stocks_list);
                Collections.sort(myStocks, new Comparator<Stocks>() {
                    @Override
                    public int compare(Stocks o1, Stocks o2) {
                        return o1.getSymbol().compareTo(o2.getSymbol());
                    }
                });
                sAdapter.notifyDataSetChanged();
            } else {
                for (int i = 0; i < stocks_list.size(); i++) {
                    String sym = stocks_list.get(i).getSymbol();
                    new LoadMy_Stock(MainActivity.this).execute(sym);
                }
            }
        }
        else {errorAlert3();}

    }

    @Override
    protected void onResume() {
        super.onResume();
        sAdapter.notifyDataSetChanged();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.new_stock, menu);
        return true;
    }

    private boolean Network_check() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) {
            Toast.makeText(this, "Error Occurred, Please restart the application", Toast.LENGTH_SHORT).show();
            return false;
        }
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnected();
    }


    private void refresh_stocks() {
        srl.setRefreshing(false);
        ArrayList<Stocks> s = sql_liteDb.loadStocks();
        for (int i = 0; i < s.size(); i++) {
            String symbol = s.get(i).getSymbol();
            new LoadMy_Stock(MainActivity.this).execute(symbol);
        }
        Toast.makeText(this, "Stocks Refreshed", Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (!Network_check()) {
            errorAlert();
            return false;
        } else {
            switch (id) {
                case R.id.new_item:
                    add_new_dialog();
                    return true;
                default:
                    return super.onOptionsItemSelected(item);
            }
        }
    }

    private void add_new_dialog() {
        if (map == null) {
            new LoadAll_Stocks(MainActivity.this).execute();
        }
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle("Select Stock");
        b.setMessage("Enter The Symbol Of Stock");
        b.setCancelable(false);
        final EditText editText = new EditText(this);
        editText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        editText.setGravity(Gravity.CENTER_HORIZONTAL);
        b.setView(editText);
        b.setPositiveButton("Add", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (!Network_check()) {          //network not available
                    errorAlert();
                    return;
                } else if (editText.getText().toString().isEmpty()) {           //empty search
                    Toast.makeText(MainActivity.this, "Please Enter Input", Toast.LENGTH_SHORT).show();
                    return;
                }
                else {
                    ArrayList<String> tempList = searchStock(editText.getText().toString());
                    if (!tempList.isEmpty()) {
                        ArrayList<String> stockOptions = new ArrayList<>(tempList);
                        if (stockOptions.size() == 1) {
                            if (checkDuplicate(stockOptions.get(0))) {
                                duplicateItem(stockOptions.get(0));
                            } else {
                                addStock(stockOptions.get(0));
                            }
                        } else {
                            multipleDialog(editText.getText().toString(), stockOptions, stockOptions.size());
                        }
                    } else {
                        no_dataAlert(editText.getText().toString());
                    }

                }
            }
        }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                return;
            }
        });
        AlertDialog dialog = b.create();
        dialog.show();
    }

    private void errorAlert() {
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle("Unable to add Stocks!!!");
        b.setMessage("Need A Network Connection To Add Stocks");
        AlertDialog a = b.create();
        a.show();
    }

    private void errorAlert2() {
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle("Unable to Refresh!!!");
        b.setMessage("Need A Network Connection To Update Stocks");
        AlertDialog a = b.create();
        a.show();
    }

    private void errorAlert3() {
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle("Unable to load Stocks!!!");
        b.setMessage("Need A Network Connection To Load Stocks");
        AlertDialog a = b.create();
        a.show();
    }

    private ArrayList<String> searchStock(String s) {
        ArrayList<String> sList = new ArrayList<>();
        if (map != null && !map.isEmpty()) {
            for (String symbol : map.keySet()) {
                String name = map.get(symbol);
                if (symbol.toUpperCase().contains(s.toUpperCase())) {
                    sList.add(symbol + " - " + name);
                } else if (name.toUpperCase().contains(s.toUpperCase())) {
                    sList.add(symbol + " - " + name);
                }

            }
        }
        return sList;
    }

    private void multipleDialog(final String s, final ArrayList<String> stockOptions, int size) {
        final String[] strings = new String[size];
        for (int i = 0; i < strings.length; i++) {
            strings[i] = stockOptions.get(i);
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Make a Selection");
        builder.setItems(strings, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (checkDuplicate(strings[which])) {
                    duplicateItem(stockOptions.get(which));
                } else {
                    addStock(strings[which]);
                }
            }
        });
        builder.setNegativeButton("Never mind", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                return;
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void no_dataAlert(String toString) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Error");
        builder.setMessage("No Stock with symbol: (" + toString + ") found, please enter valid inputs");
        AlertDialog dialog = builder.create();
        dialog.show();
    }





    private void duplicateItem(String s) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Duplicate Stock");
        int end = s.indexOf("-");
        builder.setMessage("Stock symbol '"+s.substring(0,end)+"' is already displayed");
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private boolean checkDuplicate(String s) {
        String sym = s.split("-")[0].trim();
        Stocks t = new Stocks();
        t.setSymbol(sym);
        return myStocks.contains(t);
    }

    private void addStock(String s) {
        String sym = s.split("-")[0].trim();
        new LoadMy_Stock(MainActivity.this).execute(sym);
        Stocks ss = new Stocks();
        ss.setSymbol(sym);
        ss.setName(map.get(sym));
        sql_liteDb.addStock(ss);

    }

    public void placeData(Stocks stock) {
        if (stock != null) {
            int index = myStocks.indexOf(stock);
            if (index > -1) {
                myStocks.remove(index);
            }
            myStocks.add(stock);
            Collections.sort(myStocks, new Comparator<Stocks>() {
                @Override
                public int compare(Stocks o1, Stocks o2) {
                    return o1.getSymbol().compareTo(o2.getSymbol());
                }
            });
            sAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public boolean onLongClick(View v) {
        final int identity = recycle.getChildLayoutPosition(v);
        TextView view = (TextView) v.findViewById(R.id.symbol);
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle("Delete Stock!!");
        b.setMessage("Delete Stock With Symbol " + (view.getText().toString()) + "?");
        b.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                ///TODO remove stock and notify all
                sql_liteDb.deleteStock(myStocks.get(identity).getSymbol());
                myStocks.remove(identity);
                sAdapter.notifyDataSetChanged();
                Toast.makeText(MainActivity.this, "Deleted", Toast.LENGTH_SHORT).show();
            }
        }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                return;
            }
        });
        AlertDialog dialog = b.create();
        dialog.show();
        return false;
    }

    public void setStocks(HashMap<String, String> hmap) {
        if (hmap != null && !hmap.isEmpty()) {
            this.map = hmap;
        }
    }

    @Override
    public void onClick(View view) {
        int a = recycle.getChildLayoutPosition(view);
        String marketPlaceURL = "http://www.marketwatch.com/investing/stock/" + myStocks.get(a).getSymbol();
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(marketPlaceURL));
        startActivity(intent);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        sql_liteDb.shutDown();
    }
}
