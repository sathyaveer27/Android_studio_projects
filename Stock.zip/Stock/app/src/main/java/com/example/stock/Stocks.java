package com.example.stock;

import java.io.Serializable;

public class Stocks implements Serializable {
private String symbol;
private String name;
private double value;
private double change;
private double change2;

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getValue() {
        return value;
    }

    public void setValue(double value) {
        this.value = value;
    }

    public double getChange() {
        return change;
    }

    public void setChange(double change) {
        this.change = change;
    }

    public double getChange2() {
        return change2;
    }

    public void setChange2(double change2) {
        this.change2 = change2;
    }

    public boolean equals(Object obj) {
        boolean output = false;
        if (obj == null || obj.getClass() != getClass()) {
            output = false;
        } else {
            Stocks stk = (Stocks) obj;
            if (this.symbol.equals(stk.symbol)) {
                output = true;
            }
        }
        return output;
    }

}

