package com.example.stock;

import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.Locale;

public class StockAdapter extends RecyclerView.Adapter<StockViewHolder> {

    private static final String TAG = "EmployeesAdapter";
    private List<Stocks> stocksList;
    private MainActivity mainAct;

    public StockAdapter(List<Stocks> empList, MainActivity ma) {
        this.stocksList = empList;
        mainAct = ma;
    }

    @NonNull
    @Override
    public StockViewHolder onCreateViewHolder(@NonNull final ViewGroup parent, int viewType) {
        Log.d(TAG, "onCreateViewHolder: MAKING NEW MyViewHolder");

        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.activity_show_stock, parent, false);
        itemView.setOnClickListener((View.OnClickListener) mainAct);
        itemView.setOnLongClickListener((View.OnLongClickListener) mainAct);


        return new StockViewHolder(itemView);
    }
    @Override
    public void onBindViewHolder(@NonNull StockViewHolder holder, int position) {
        Log.d(TAG, "onBindViewHolder: FILLING VIEW HOLDER Employee " + position);

        Stocks stock = stocksList.get(position);

        if(stock.getChange2() < 0){
            setRed(holder);
        }
        else if(stock.getChange2() >= 0) {
            setGreen(holder);
        }
        set(holder, stock);

    }

    private void set(StockViewHolder holder, Stocks stock) {
        holder.name.setText(stock.getName());
        holder.symbol.setText(stock.getSymbol());
        holder.value.setText(String.format(Locale.US, "%.2f", stock.getValue()));
        holder.change.setText(String.format(Locale.US, "%.2f", stock.getChange()));
        holder.change2.setText(String.format(Locale.US, "(%.2f%%)", stock.getChange2()));
    }

    private void setRed(StockViewHolder holder) {
        holder.name.setTextColor(Color.RED);
        holder.symbol.setTextColor(Color.RED);
        holder.value.setTextColor(Color.RED);
        holder.change.setTextColor(Color.RED);
        holder.change2.setTextColor(Color.RED);
        holder.arrow.setImageResource(R.drawable.down);
        holder.arrow.setColorFilter(Color.RED);
    }

    private void setGreen(StockViewHolder holder) {
        holder.name.setTextColor(Color.GREEN);
        holder.symbol.setTextColor(Color.GREEN);
        holder.value.setTextColor(Color.GREEN);
        holder.change.setTextColor(Color.GREEN);
        holder.change2.setTextColor(Color.GREEN);
        holder.arrow.setImageResource(R.drawable.up);
        holder.arrow.setColorFilter(Color.GREEN);
    }

    @Override
    public int getItemCount() { return stocksList.size(); }

}
