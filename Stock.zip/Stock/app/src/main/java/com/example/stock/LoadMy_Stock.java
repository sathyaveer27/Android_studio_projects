package com.example.stock;

import android.net.Uri;
import android.os.AsyncTask;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class LoadMy_Stock extends AsyncTask<String,Void,String> {
    private static final String URL_1 = "https://cloud.iexapis.com/stable/stock/";
    private static final String URL_2 = "/quote?token=sk_54acbdc09fac4750b8e3dad0e738c05c";
    private MainActivity mainAct;

    public LoadMy_Stock(MainActivity mainActivity) {
        this.mainAct = mainActivity;
    }

    @Override
    protected String doInBackground(String... string) {
        String API_URL = URL_1 + string[0] + URL_2;
        Uri uri = Uri.parse(API_URL);
        StringBuilder sb = new StringBuilder();
        String my_socks = uri.toString();
        try {
            URL url_my = new URL(my_socks);
            HttpsURLConnection conn = (HttpsURLConnection) url_my.openConnection();
            conn.setRequestMethod("GET");
            InputStream is = conn.getInputStream();
            BufferedReader bir = new BufferedReader(new InputStreamReader(is));
            String line;
            while((line = bir.readLine())!=null){
                sb.append(line);
                sb.append("\n");
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return sb.toString();
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        Stocks stock = jsonToMap(s);
        mainAct.placeData(stock);
    }

    private Stocks jsonToMap(String s) {
        Stocks ss = new Stocks();
        try {
            JSONObject jsonObject = new JSONObject(s);
            String symbol = jsonObject.getString("symbol");
            String name = jsonObject.getString("companyName");
            double value = jsonObject.getDouble("latestPrice");
            double change = jsonObject.getDouble("change");
            double change2 = jsonObject.getDouble("changePercent");

            ss.setName(name);
            ss.setSymbol(symbol);
            ss.setValue(value);
            ss.setChange(change);
            ss.setChange2(change2);
            return ss;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }
}
