package com.example.stock;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import java.util.ArrayList;

public class SQL_liteDb extends SQLiteOpenHelper{

    private static final String TAG = "SQL_liteDb";
    private static final String DATABASE_NAME = "StockAppDB";
    private static final String TABLE_NAME = "StockWatchTable";
    private static final String SYMBOL = "StockSymbol";
    private static final String COMPANY = "CompanyName";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLECREATE = "CREATE TABLE " + TABLE_NAME + " (" + SYMBOL + " TEXT not null unique," + COMPANY + " TEXT not null)";
    private SQLiteDatabase database;

    public SQL_liteDb(Context c){
        super(c, DATABASE_NAME, null, DATABASE_VERSION);
        database = getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLECREATE);
        Log.d(TAG, "onCreate: Table Created");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldV, int newV) {


    }

    public void deleteStock(String symbol) {
        Log.d(TAG, "deleteStock: Deleting Stock " + symbol);
        int cnt = database.delete(TABLE_NAME, SYMBOL + " = ?", new String[] { symbol });
        Log.d(TAG, "deleteStock: " + cnt);
    }


    public void addStock(Stocks stock) {
        Log.d(TAG, "addStock: Adding " + stock.getSymbol());
        ContentValues values = new ContentValues();
        values.put(SYMBOL, stock.getSymbol());
        values.put(COMPANY, stock.getName());
        database.insert(TABLE_NAME, null, values);
        Log.d(TAG, "addStock: Add Complete");
    }

    public ArrayList<Stocks> loadStocks() {

        ArrayList<Stocks> stocks = new ArrayList<>();
        Cursor cursor = database.query(
                TABLE_NAME, // The table to query
                new String[]{SYMBOL, COMPANY}, // The columns to return
                null, // The columns for the WHERE clause
                null, // The values for the WHERE clause
                null, // don't group the rows
                null, // don't filter by row groups
                null); // The sort order
        if (cursor != null) {
            cursor.moveToFirst();
            for (int i = 0; i < cursor.getCount(); i++) {
                String symbol = cursor.getString(0);
                String company = cursor.getString(1);
                Stocks s = new Stocks();
                s.setSymbol(symbol);
                s.setName(company);
                s.setValue(0.0);
                s.setChange(0.0);
                s.setChange2(0.0);
                stocks.add(s);
                cursor.moveToNext();
            }
            cursor.close();
        }
        return stocks;
    }

    public void shutDown() {
        database.close();
    }


}
