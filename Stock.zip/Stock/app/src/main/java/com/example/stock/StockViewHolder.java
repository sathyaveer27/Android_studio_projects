package com.example.stock;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

public class StockViewHolder extends RecyclerView.ViewHolder {
    public TextView symbol;
    public TextView name;
    public TextView value;
    public TextView change;
    public TextView change2;
    public ImageView arrow;

    public StockViewHolder(View v){
        super(v);
        symbol =v.findViewById(R.id.symbol);
        name = v.findViewById(R.id.name);
        value = v.findViewById(R.id.value);
        change = v.findViewById(R.id.change);
        change2 = v.findViewById(R.id.change2);
        arrow = v.findViewById(R.id.arrow);
    }
}
