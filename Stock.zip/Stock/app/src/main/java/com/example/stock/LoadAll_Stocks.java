package com.example.stock;

import android.net.Uri;
import android.os.AsyncTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;

import javax.net.ssl.HttpsURLConnection;

public class LoadAll_Stocks extends AsyncTask<Void,Void,String> {
    private MainActivity mainAct;
    private static final String ALLURL = "https://api.iextrading.com/1.0/ref-data/symbols";
    public LoadAll_Stocks(MainActivity mainAct){this.mainAct = mainAct;}
    @Override
    protected String doInBackground(Void... voids) {
        Uri uri = Uri.parse(ALLURL);
        StringBuilder sb = new StringBuilder();
        String url_all = uri.toString();
        try {
            URL all = new URL(url_all);
            HttpsURLConnection conn = (HttpsURLConnection)all.openConnection();
            conn.setRequestMethod("GET");
            InputStream is = conn.getInputStream();
            BufferedReader bir = new BufferedReader(new InputStreamReader(is));
            String line;
            while ((line=bir.readLine())!=null){
                sb.append(line);
                sb.append("\n");
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return sb.toString();
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        HashMap<String,String> hashMap = jsonToMap(s);
        mainAct.setStocks(hashMap);
    }

    private HashMap<String, String> jsonToMap(String s) {
        HashMap<String,String> string_HMap = new HashMap<>();
        try {
            JSONArray jsonArray = new JSONArray(s);
            for (int i = 0;i<jsonArray.length();i++){
                JSONObject jsonObject = (JSONObject) jsonArray.get(i);
                String symbol = jsonObject.getString("symbol");
                String name = jsonObject.getString("name");
                string_HMap.put(symbol,name);
            }
            return string_HMap;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }
}
